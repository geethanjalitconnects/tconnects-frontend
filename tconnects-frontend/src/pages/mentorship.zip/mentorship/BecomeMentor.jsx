import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";
import { mentorshipApi } from "../../services/mentorshipApi";
import "./mentorship.css";

const initial = {
  city: "",
  country: "India",
  languages: ["English"],
  linkedin_url: "",
  job_title: "",
  company_name: "",
  hide_company: false,
  company_display_label: "",
  years_experience: "",
  risk_areas: [],
  highest_qualification: "",
  certifications: [],
  past_roles: [],
  topics: [],
  audiences: ["students", "freshers"],
  session_types: ["career_guidance"],
  help_summary: "",
  real_moment: "",
  common_mistake: "",
  session_durations: [30],
  hourly_rate: "",
  availability: {},
  free_intro_call: false,
  has_no_work_email: false,
  note_for_team: "",
  accept_code_of_conduct: false,
};

const defaultOptions = {
  risk_areas: [
    { value: "credit", label: "Credit risk" },
    { value: "market", label: "Market risk" },
    { value: "operational", label: "Operational risk" },
    { value: "compliance", label: "Compliance & regulatory" },
    { value: "fintech", label: "Fintech & digital risk" },
    { value: "audit", label: "Internal audit" },
    { value: "cyber", label: "Cyber & information risk" },
    { value: "insurance", label: "Insurance & actuarial risk" },
    { value: "other", label: "Other" },
  ],
  audiences: [
    { value: "students", label: "Students" },
    { value: "freshers", label: "Freshers" },
    { value: "career_switchers", label: "Career switchers" },
    { value: "working_professionals", label: "Working professionals" },
  ],
  session_types: [
    { value: "career_guidance", label: "Career guidance" },
    { value: "resume_review", label: "Resume review" },
    { value: "interview_prep", label: "Interview prep" },
    { value: "skill_learning", label: "Learning a skill" },
    { value: "project_help", label: "Project help" },
  ],
  session_durations: [30, 45, 60],
  topic_suggestions: [
    "Credit risk modelling",
    "Basel norms",
    "Operational risk & RCSA",
    "Fraud risk",
    "AML / KYC",
    "Model validation",
    "Market risk & VaR",
    "Liquidity risk & ALM",
    "RBI regulations",
    "Third-party risk",
    "Cyber risk",
    "Risk analytics (Python / SQL)",
    "Enterprise risk management",
    "Interview preparation",
    "Switching into risk",
  ],
  certification_suggestions: [
    "FRM", "PRM", "CRISC", "CAMS", "CISA", "CFA", "CA", "ACCA", "CIA",
  ],
  weekdays: ["mon", "tue", "wed", "thu", "fri", "sat", "sun"],
};

function Field({ label, hint, children }) {
  return (
    <label className="mentor-form-field">
      <span>{label}</span>
      {children}
      {hint && <small>{hint}</small>}
    </label>
  );
}

function CheckPills({ values = [], selected = [], onChange }) {
  return (
    <div className="mentor-select-pills">
      {values.map((item) => {
        const option =
          typeof item === "string"
            ? { value: item, label: item }
            : item;

        const checked = selected.includes(option.value);

        return (
          <button
            type="button"
            key={option.value}
            className={`mentor-select-pill ${checked ? "selected" : ""}`}
            aria-pressed={checked}
            onClick={() =>
              onChange(
                checked
                  ? selected.filter((value) => value !== option.value)
                  : [...selected, option.value]
              )
            }
          >
            {checked ? "✓ " : "+ "}
            {option.label}
          </button>
        );
      })}
    </div>
  );
}

function errorText(err) {
  const data = err?.response?.data;

  if (typeof data === "string") return data;
  if (data?.detail) {
    const missing = data.missing;
    if (missing && typeof missing === "object") {
      const fields = Object.values(missing).flat();
      return `${data.detail} ${fields.length ? `Missing: ${fields.join(", ")}.` : ""}`;
    }
    return data.detail;
  }

  if (data?.error && data?.detail) return data.detail;

  if (data && typeof data === "object") {
    return Object.entries(data)
      .map(([key, value]) => {
        const messages = Array.isArray(value) ? value.join(" ") : String(value);
        return `${key.replaceAll("_", " ")}: ${messages}`;
      })
      .join(" ");
  }

  if (err?.message) return err.message;
  return "Something went wrong. Please check your details and try again.";
}

function normaliseApplication(data = {}) {
  return {
    ...initial,
    ...data,
    city: data.city ?? data.prefill?.city ?? "",
    country: data.country || "India",
    languages: Array.isArray(data.languages) ? data.languages : ["English"],
    risk_areas: Array.isArray(data.risk_areas) ? data.risk_areas : [],
    certifications: Array.isArray(data.certifications) ? data.certifications : [],
    past_roles: Array.isArray(data.past_roles) ? data.past_roles : [],
    topics: Array.isArray(data.topics) ? data.topics : [],
    audiences: Array.isArray(data.audiences) ? data.audiences : [],
    session_types: Array.isArray(data.session_types) ? data.session_types : [],
    session_durations: Array.isArray(data.session_durations)
      ? data.session_durations.map(Number)
      : [30],
    availability:
      data.availability && typeof data.availability === "object"
        ? data.availability
        : {},
    hourly_rate: data.hourly_rate ?? "",
    years_experience: data.years_experience ?? "",
    accept_code_of_conduct: Boolean(data.code_of_conduct_accepted),
    has_no_work_email: Boolean(data.has_no_work_email),
  };
}

const isEditableStatus = (status) =>
  !status || ["not_started", "draft", "changes_requested", "rejected"].includes(status);

export default function BecomeMentor() {
  const [form, setForm] = useState(initial);
  const [status, setStatus] = useState(null);
  const [options, setOptions] = useState(defaultOptions);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState("");
  const [sendingOtp, setSendingOtp] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [workEmail, setWorkEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [availabilityText, setAvailabilityText] = useState("{}");
  const [error, setError] = useState("");
  // Why the application could not be loaded: "auth" (401), "forbidden" (403), "other"
  const [errorType, setErrorType] = useState("");
  const [message, setMessage] = useState("");
  // Open directly on the first form section instead of the welcome/sign-in gate.
  const [currentStep, setCurrentStep] = useState(1);

  const steps = [
    { title: "Welcome", short: "Start" },
    { title: "Your profile", short: "Profile" },
    { title: "Your experience", short: "Experience" },
    { title: "Your mentoring", short: "Mentoring" },
    { title: "Sessions & pricing", short: "Sessions" },
    { title: "Verification", short: "Verify" },
  ];

  const goToStep = (nextStep) => {
    setCurrentStep(Math.max(0, Math.min(steps.length - 1, nextStep)));
    setError("");
    setMessage("");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const update = (key, value) => {
    setForm((old) => ({ ...old, [key]: value }));
  };

  useEffect(() => {
    let active = true;

    async function load() {
      try {
        const [optionsResult, applicationResult] = await Promise.allSettled([
          mentorshipApi.getOptions(),
          mentorshipApi.getApplication(),
        ]);

        if (!active) return;

        if (optionsResult.status === "fulfilled") {
          setOptions((old) => ({
            ...old,
            ...optionsResult.value,
          }));
        }

        if (applicationResult.status === "fulfilled") {
          const current = applicationResult.value;
          setStatus(current);
          setForm(normaliseApplication(current));
          setAvailabilityText(JSON.stringify(current.availability || {}, null, 2));
          setWorkEmail("");
          setErrorType("");
        } else {
          const err = applicationResult.reason;
          const code = err?.response?.status;

          if (code === 401) {
            // Let visitors fill the form first. The existing backend still requires
            // a signed-in candidate account for saving, uploads, OTP verification,
            // and final submission.
            setErrorType("auth");
            setError("");
            setMessage(
              "You can fill in the application form now. Please sign in with your candidate account before saving, uploading files, verifying your work email, or submitting. Your entries are not saved until you sign in."
            );
          } else if (code === 403) {
            // Signed in, but this account is not allowed to apply
            setErrorType("forbidden");
            setError(
              err?.response?.data?.detail ||
                "This account can't apply as a mentor. Mentor applications are available to candidate accounts."
            );
          } else {
            setErrorType("other");
            setError(errorText(err));
          }
        }

        if (optionsResult.status === "rejected") {
          console.error("Could not load mentor options:", optionsResult.reason);
        }
      } finally {
        if (active) setLoading(false);
      }
    }

    load();

    return () => {
      active = false;
    };
  }, []);

  function pickFrom(source, keys) {
    return Object.fromEntries(keys.map((key) => [key, source[key]]));
  }

  const save = async ({ quiet = false, sectionsOnly = null } = {}) => {
    setSaving(true);
    setError("");
    if (!quiet) setMessage("");

    try {
      let currentStatus = status;

      if (!currentStatus || currentStatus.status === "not_started") {
        currentStatus = await mentorshipApi.startApplication();
        setStatus(currentStatus);
      }

      if (currentStatus?.can_edit === false) {
        throw new Error("This application is locked and can no longer be edited.");
      }

      let availability = form.availability || {};
      if (!sectionsOnly || sectionsOnly.includes(5)) {
        try {
          availability = JSON.parse(availabilityText || "{}");
        } catch {
          throw new Error("Availability must be valid JSON. Please correct it before saving.");
        }

        if (!availability || typeof availability !== "object" || Array.isArray(availability)) {
          throw new Error("Availability must be a weekly schedule in JSON format.");
        }
      }

      const data = { ...form, availability };

      const groups = [
        {
          section: 1,
          data: pickFrom(data, [
            "city", "country", "languages", "linkedin_url",
          ]),
        },
        {
          section: 2,
          data: pickFrom(data, [
            "job_title", "company_name", "hide_company",
            "company_display_label", "years_experience", "risk_areas",
            "highest_qualification", "certifications", "past_roles",
          ]),
        },
        {
          section: 3,
          data: pickFrom(data, [
            "topics", "audiences", "session_types", "help_summary",
          ]),
        },
        {
          section: 4,
          data: pickFrom(data, ["real_moment", "common_mistake"]),
        },
        {
          section: 5,
          data: pickFrom(data, [
            "session_durations", "hourly_rate", "availability", "free_intro_call",
          ]),
        },
        {
          section: 6,
          data: pickFrom(data, [
            "has_no_work_email", "note_for_team",
            "accept_code_of_conduct",
          ]),
        },
      ];

      const groupsToSave = sectionsOnly
        ? groups.filter((group) => sectionsOnly.includes(group.section))
        : groups;
      let latest = currentStatus;

      for (const group of groupsToSave) {
        latest = await mentorshipApi.saveSection(group.section, group.data);
      }

      setStatus(latest);
      if (!sectionsOnly || sectionsOnly.includes(5)) update("availability", availability);
      if (!quiet) {
        setMessage("Your application draft has been saved.");
        toast.success("Application saved");
      }

      return latest;
    } catch (err) {
      const text = errorText(err);
      setError(text);
      if (!quiet) toast.error(text);
      throw err;
    } finally {
      setSaving(false);
    }
  };

  const handleUpload = async (kind, file) => {
    if (!file) return;

    setError("");
    setMessage("");
    setUploading(kind);

    try {
      const current = status;

      if (!current || current.status === "not_started") {
        const started = await mentorshipApi.startApplication();
        setStatus(started);
      }

      await mentorshipApi.uploadFile(kind, file);

      const updated = await mentorshipApi.getApplication();
      setStatus(updated);
      setForm(normaliseApplication(updated));

      setAvailabilityText(JSON.stringify(updated.availability || {}, null, 2));
      setMessage(
        kind === "photo"
          ? "Profile photo uploaded."
          : kind === "video"
            ? "Introduction video uploaded."
            : "Verification document uploaded."
      );
      toast.success("File uploaded successfully");
    } catch (err) {
      const text = errorText(err);
      setError(text);
      toast.error(text);
    } finally {
      setUploading("");
    }
  };

  const removeUpload = async (kind) => {
    setError("");
    setUploading(kind);

    try {
      await mentorshipApi.removeFile(kind);
      const updated = await mentorshipApi.getApplication();
      setStatus(updated);
      setForm(normaliseApplication(updated));
      setMessage("File removed.");
      toast.success("File removed");
    } catch (err) {
      const text = errorText(err);
      setError(text);
      toast.error(text);
    } finally {
      setUploading("");
    }
  };

  const sendOtp = async () => {
    if (!workEmail.trim()) {
      setError("Enter your professional work email first.");
      return;
    }

    setSendingOtp(true);
    setError("");
    setMessage("");

    try {
      if (!status || status.status === "not_started") {
        const started = await mentorshipApi.startApplication();
        setStatus(started);
      }

      await mentorshipApi.sendWorkEmailOtp(workEmail.trim());
      setOtpSent(true);
      setMessage("Verification code sent. Check your work email.");
      toast.success("Verification code sent");
    } catch (err) {
      const text = errorText(err);
      setError(text);
      toast.error(text);
    } finally {
      setSendingOtp(false);
    }
  };

  const verifyOtp = async () => {
    if (!/^\d{6}$/.test(otp.trim())) {
      setError("Enter the 6-digit code sent to your work email.");
      return;
    }

    setVerifyingOtp(true);
    setError("");
    setMessage("");

    try {
      await mentorshipApi.verifyWorkEmailOtp(otp.trim());
      const updated = await mentorshipApi.getApplication();
      setStatus(updated);
      setForm(normaliseApplication(updated));
      setMessage("Your work email has been verified successfully.");
      setOtpSent(false);
      setOtp("");
      toast.success("Work email verified");
    } catch (err) {
      const text = errorText(err);
      setError(text);
      toast.error(text);
    } finally {
      setVerifyingOtp(false);
    }
  };

  const submit = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setMessage("");

    try {
      await save({ quiet: true });

      const result = await mentorshipApi.submitApplication();
      setStatus(result);
      setMessage(
        result.message ||
          "Your application has been submitted for review."
      );
      toast.success("Application submitted for review");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (err) {
      const text = errorText(err);
      setError(text);
      toast.error(text);
      window.scrollTo({ top: 0, behavior: "smooth" });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <main className="mentorship-page">
        <p className="mentor-state">Loading your application…</p>
      </main>
    );
  }

  /* The application could not be loaded: show the right message for the cause */
  if (errorType && !status && errorType !== "auth") {
    const isAuth = errorType === "auth";
    const isForbidden = errorType === "forbidden";

    return (
      <main className="mentorship-page mentor-application-state">
        <div className="mentor-status-icon">!</div>
        <span className="mentor-eyebrow">MENTOR APPLICATION</span>
        <h1>
          {isAuth
            ? "Sign in to continue"
            : isForbidden
              ? "This account can't apply as a mentor"
              : "Something went wrong"}
        </h1>
        <p>{error}</p>

        {isForbidden && (
          <p>Sign out and sign in with a candidate account to continue.</p>
        )}

        {errorType === "other" && (
          <button
            type="button"
            className="mentor-btn mentor-btn-primary"
            onClick={() => window.location.reload()}
          >
            Try again
          </button>
        )}

        <p style={{ marginTop: 16 }}>
          <Link to="/mentorship">Back to mentorship</Link>
        </p>
      </main>
    );
  }

  if (status?.status && !isEditableStatus(status.status)) {
    return (
      <main className="mentorship-page mentor-application-state">
        <div className="mentor-status-icon">✓</div>
        <span className="mentor-eyebrow">MENTOR APPLICATION</span>
        <h1>
          {status.status === "approved"
            ? "Your mentor profile is approved."
            : status.status === "submitted"
              ? "Your application is with our review team."
              : "Your application status has been updated."}
        </h1>
        <p>
          {status.status === "approved"
            ? "Your profile has been approved by TConnects."
            : status.review_message ||
              "Thank you for your interest in joining TConnects. Your profile will not be published or bookable until all required checks are completed and approved."}
        </p>
        <Link className="mentor-btn mentor-btn-primary" to="/mentorship">
          Back to mentorship
        </Link>
      </main>
    );
  }

  const photoUrl = status?.photo_url;
  const videoUrl = status?.intro_video_url;
  const proofName = status?.proof_document_name;
  const workEmailVerified = Boolean(status?.work_email_verified);

  return (
    <main className="mentorship-page become-mentor-page">
      {currentStep > 0 && (
        <section className="become-mentor-intro">
          <span className="mentor-eyebrow">
            TCONNECTS VERIFIED MENTOR NETWORK
          </span>
          <h1>Your experience can shape someone's future.</h1>
          <p>
            Tell us about your professional background and what you can help
            others learn. The application takes around 5–6 minutes. Final
            onboarding includes independent verification and a quality review.
          </p>
          <div className="mentor-review-points">
            <span><i className="bi bi-shield-check" /> Professional checks</span>
            <span><i className="bi bi-person-check" /> Human review</span>
            <span><i className="bi bi-patch-check" /> Approval before listing</span>
          </div>
        </section>
      )}

      {error && (
        <div className="mentor-form-alert error" role="alert">
          {error}
        </div>
      )}
      {message && (
        <div className="mentor-form-alert success" role="status">
          {message}
        </div>
      )}

      {status?.status === "changes_requested" && status.review_message && (
        <div className="mentor-form-alert error" role="status">
          <strong>Changes requested by the review team:</strong>{" "}
          {status.review_message}
        </div>
      )}

      <form className="mentor-application-form" onSubmit={submit}>
        {currentStep > 0 && (
          <div className="mentor-wizard-top">
            <div className="mentor-wizard-topline">
              <span className="mentor-section-kicker">MENTOR APPLICATION</span>
              <span className="mentor-wizard-count">Step {currentStep} of {steps.length - 1}</span>
            </div>
            <div className="mentor-wizard-progress" role="progressbar" aria-valuemin={0} aria-valuemax={steps.length - 1} aria-valuenow={currentStep}>
              <span style={{ width: `${(currentStep / (steps.length - 1)) * 100}%` }} />
            </div>
            <div className="mentor-wizard-step-labels">
              {steps.slice(1).map((step, index) => (
                <button key={step.short} type="button" className={currentStep === index + 1 ? "active" : currentStep > index + 1 ? "complete" : ""} onClick={() => currentStep > index + 1 && goToStep(index + 1)} disabled={currentStep <= index + 1}>
                  <span>{currentStep > index + 1 ? "✓" : index + 1}</span>{step.short}
                </button>
              ))}
            </div>
          </div>
        )}

        {currentStep === 0 && (
          <section className="mentor-welcome-step">
            <div className="mentor-welcome-copy">
              <span className="mentor-welcome-icon"><i className="bi bi-stars" /></span>
              <span className="mentor-section-kicker">TCONNECTS VERIFIED MENTOR NETWORK</span>
              <h2>Turn your experience into someone else's next opportunity.</h2>
              <p>Build your mentor profile in a few short steps. Choose from simple options, save your progress, and return whenever you're ready.</p>
              <div className="mentor-welcome-benefits">
                <div><i className="bi bi-clock" /><span><b>About 5–6 minutes</b><small>Complete it at your own pace</small></span></div>
                <div><i className="bi bi-cloud-check" /><span><b>Save and come back</b><small>Your draft can be continued later</small></span></div>
                <div><i className="bi bi-shield-check" /><span><b>Private verification</b><small>Your profile is reviewed before publishing</small></span></div>
              </div>
              <button type="button" className="mentor-btn mentor-btn-primary mentor-welcome-cta" onClick={() => goToStep(1)}>Build my profile <i className="bi bi-arrow-right" /></button>
              <p className="mentor-welcome-footnote">You can review your details before submitting. Your profile will not be public or bookable until TConnects approves it.</p>
            </div>
            <div className="mentor-welcome-art" aria-hidden="true">
              <div className="mentor-welcome-orbit orbit-a" /><div className="mentor-welcome-orbit orbit-b" />
              <div className="mentor-welcome-card"><span className="mentor-welcome-card-icon"><i className="bi bi-person-check" /></span><small>YOUR NEXT CHAPTER</small><strong>Share what you know.<br/>Help someone grow.</strong><div className="mentor-welcome-mini-tags"><span>Risk expertise</span><span>Career guidance</span><span>Real impact</span></div></div>
              <div className="mentor-welcome-floating"><i className="bi bi-patch-check-fill" /><span><b>Verified mentors</b><small>Trust comes first</small></span></div>
            </div>
          </section>
        )}

        {currentStep === 1 && (
          <section className="mentor-form-section">
          <div className="mentor-form-section-heading">
            <div>
              <span className="mentor-section-kicker">YOUR PROFILE</span>
              <h2>Let's get to know you</h2>
              <p>Use the details that match your professional records.</p>
            </div>
          </div>

          <div className="mentor-form-grid">
            <Field label="City">
              <input
                required
                maxLength={100}
                value={form.city}
                onChange={(e) => update("city", e.target.value)}
                placeholder="e.g. Chennai"
              />
            </Field>

            <Field label="Country">
              <input
                required
                maxLength={100}
                value={form.country}
                onChange={(e) => update("country", e.target.value)}
              />
            </Field>

            <Field
              label="LinkedIn profile"
              hint="Used to review your professional background."
            >
              <input
                type="url"
                required
                value={form.linkedin_url}
                onChange={(e) => update("linkedin_url", e.target.value)}
                placeholder="https://www.linkedin.com/in/your-name"
              />
            </Field>

            <Field
              label="Languages you can mentor in"
              hint="Separate languages with commas."
            >
              <input
                required
                value={form.languages.join(", ")}
                onChange={(e) =>
                  update(
                    "languages",
                    e.target.value.split(",").map((x) => x.trim()).filter(Boolean)
                  )
                }
                placeholder="English, Tamil"
              />
            </Field>
          </div>

          <Field
            label="Professional profile photo"
            hint="JPG, PNG or WebP. Maximum 5 MB."
          >
            {photoUrl && (
              <div style={{ marginBottom: 12 }}>
                <img
                  src={photoUrl}
                  alt="Current mentor profile"
                  style={{
                    width: 110,
                    height: 110,
                    objectFit: "cover",
                    borderRadius: "50%",
                  }}
                />
                <p>
                  <button
                    type="button"
                    className="mentor-btn mentor-btn-outline"
                    disabled={Boolean(uploading)}
                    onClick={() => removeUpload("photo")}
                  >
                    Remove photo
                  </button>
                </p>
              </div>
            )}
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={(e) => {
                handleUpload("photo", e.target.files?.[0]);
                e.target.value = "";
              }}
              disabled={Boolean(uploading)}
            />
            {uploading === "photo" && <small>Uploading photo…</small>}
          </Field>
        </section>
        )}

        {currentStep === 2 && (
          <section className="mentor-form-section">
          <div className="mentor-form-section-heading">
            <div>
              <span className="mentor-section-kicker">YOUR EXPERIENCE</span>
              <h2>What have you worked on?</h2>
              <p>We review professional experience as part of our quality checks.</p>
            </div>
          </div>

          <div className="mentor-form-grid">
            <Field label="Current job title">
              <input
                required
                value={form.job_title}
                onChange={(e) => update("job_title", e.target.value)}
                placeholder="e.g. Senior Risk Analyst"
              />
            </Field>

            <Field label="Current company">
              <input
                required
                value={form.company_name}
                onChange={(e) => update("company_name", e.target.value)}
                placeholder="Company or organisation"
              />
            </Field>

            <Field label="Years of relevant experience">
              <input
                required
                type="number"
                min="1"
                max="60"
                value={form.years_experience}
                onChange={(e) => update("years_experience", e.target.value)}
                placeholder="e.g. 5"
              />
            </Field>

            <Field label="Highest qualification">
              <input
                required
                value={form.highest_qualification}
                onChange={(e) => update("highest_qualification", e.target.value)}
                placeholder="Degree or professional qualification"
              />
            </Field>
          </div>

          <Field label="Risk-management areas you specialise in">
            <CheckPills
              values={options.risk_areas}
              selected={form.risk_areas}
              onChange={(v) => update("risk_areas", v)}
            />
          </Field>

          <Field
            label="Certifications"
            hint="Separate multiple certifications with commas."
          >
            <input
              value={form.certifications.join(", ")}
              onChange={(e) =>
                update(
                  "certifications",
                  e.target.value.split(",").map((x) => x.trim()).filter(Boolean)
                )
              }
              placeholder="e.g. CISA, CRISC, FRM"
            />
            {options.certification_suggestions?.length > 0 && (
              <small>
                Suggestions: {options.certification_suggestions.join(", ")}
              </small>
            )}
          </Field>

          <Field label="Display company name publicly?">
            <div className="mentor-inline-choice">
              <label>
                <input
                  type="checkbox"
                  checked={form.hide_company}
                  onChange={(e) => update("hide_company", e.target.checked)}
                />
                Keep my company name private on my public profile
              </label>
            </div>
          </Field>

          {form.hide_company && (
            <Field
              label="Public company label"
              hint="For example: Leading financial services firm."
            >
              <input
                required
                value={form.company_display_label}
                onChange={(e) => update("company_display_label", e.target.value)}
                placeholder="A non-identifying description"
              />
            </Field>
          )}
        </section>
        )}

        {currentStep === 3 && (
          <section className="mentor-form-section">
          <div className="mentor-form-section-heading">
            <div>
              <span className="mentor-section-kicker">YOUR MENTORING</span>
              <h2>What can people learn from you?</h2>
              <p>Help candidates understand where your guidance is most useful.</p>
            </div>
          </div>

          <Field label="Topics you can help with">
            <CheckPills
              values={options.topic_suggestions || []}
              selected={form.topics}
              onChange={(v) => update("topics", v)}
            />
            <small>Select up to 5 topics.</small>
          </Field>

          <Field
            label="Additional topics"
            hint="Optional. Separate topics with commas; total topics must not exceed 5."
          >
            <input
              value={form.topics.join(", ")}
              onChange={(e) =>
                update(
                  "topics",
                  [...new Set(e.target.value.split(",").map((x) => x.trim()).filter(Boolean))]
                    .slice(0, 5)
                )
              }
              placeholder="e.g. Risk reporting, stakeholder communication"
            />
          </Field>

          <div className="mentor-form-grid">
            <Field label="Who would you like to mentor?">
              <CheckPills
                values={options.audiences}
                selected={form.audiences}
                onChange={(v) => update("audiences", v)}
              />
            </Field>

            <Field label="Session formats">
              <CheckPills
                values={options.session_types}
                selected={form.session_types}
                onChange={(v) => update("session_types", v)}
              />
            </Field>
          </div>

          <Field label="What can a mentee expect from a session?">
            <textarea
              required
              rows={3}
              maxLength={1000}
              value={form.help_summary}
              onChange={(e) => update("help_summary", e.target.value)}
              placeholder="Describe the practical guidance or outcomes you can offer…"
            />
          </Field>

          <div className="mentor-form-grid">
            <Field
              label="Share a real-world risk challenge you handled"
              hint="At least 50 characters. Do not include confidential company or client information."
            >
              <textarea
                required
                minLength={50}
                rows={4}
                maxLength={500}
                value={form.real_moment}
                onChange={(e) => update("real_moment", e.target.value)}
                placeholder="Briefly describe the challenge, your approach, and the outcome…"
              />
            </Field>

            <Field label="What is a common mistake you help people avoid?">
              <textarea
                required
                rows={4}
                value={form.common_mistake}
                onChange={(e) => update("common_mistake", e.target.value)}
                placeholder="Describe a practical lesson you teach…"
              />
            </Field>
          </div>

          <Field
            label="Introduction video (optional)"
            hint="MP4, MOV or WebM. Maximum 50 MB."
          >
            {videoUrl && (
              <p>
                <a href={videoUrl} target="_blank" rel="noreferrer">
                  View uploaded introduction video
                </a>{" "}
                <button
                  type="button"
                  className="mentor-btn mentor-btn-outline"
                  disabled={Boolean(uploading)}
                  onClick={() => removeUpload("video")}
                >
                  Remove
                </button>
              </p>
            )}
            <input
              type="file"
              accept="video/mp4,video/quicktime,video/webm"
              onChange={(e) => {
                handleUpload("video", e.target.files?.[0]);
                e.target.value = "";
              }}
              disabled={Boolean(uploading)}
            />
            {uploading === "video" && <small>Uploading video…</small>}
          </Field>
        </section>
        )}

        {currentStep === 4 && (
          <section className="mentor-form-section">
          <div className="mentor-form-section-heading">
            <div>
              <span className="mentor-section-kicker">SESSIONS & PRICING</span>
              <h2>Set your mentoring preferences</h2>
              <p>Proposed details are subject to TConnects review and approval.</p>
            </div>
          </div>

          <div className="mentor-form-grid">
            <Field label="Proposed hourly rate (₹)">
              <input
                required
                type="number"
                min="1"
                max="1000000"
                value={form.hourly_rate}
                onChange={(e) => update("hourly_rate", e.target.value)}
                placeholder="e.g. 5000"
              />
            </Field>

            <Field label="Session durations">
              <CheckPills
                values={(options.session_durations || [30, 45, 60]).map((n) => ({
                  value: n,
                  label: `${n} minutes`,
                }))}
                selected={form.session_durations}
                onChange={(v) =>
                  update("session_durations", v.map(Number).sort((a, b) => a - b))
                }
              />
            </Field>
          </div>

          <Field
            label="Weekly availability"
            hint='Use the weekday keys mon, tue, wed, thu, fri, sat, sun and time slots such as "18:00-20:00". At least one slot is required.'
          >
            <textarea
              required
              rows={5}
              value={availabilityText}
              onChange={(e) => {
                setAvailabilityText(e.target.value);
                try {
                  const parsed = JSON.parse(e.target.value || "{}");
                  if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
                    update("availability", parsed);
                  }
                } catch {
                  // Keep the typed text; validation happens when saving.
                }
              }}
              placeholder={'{\n  "mon": ["18:00-20:00"],\n  "sat": ["10:00-12:00"]\n}'}
            />
          </Field>

          <label className="mentor-consent">
            <input
              type="checkbox"
              checked={form.free_intro_call}
              onChange={(e) => update("free_intro_call", e.target.checked)}
            />
            <span>I can offer a free introductory call.</span>
          </label>
        </section>
        )}

        {currentStep === 5 && (
          <section className="mentor-form-section">
          <div className="mentor-form-section-heading">
            <div>
              <span className="mentor-section-kicker">VERIFICATION & TRUST</span>
              <h2>Help us verify your profile</h2>
              <p>
                These checks protect learners and maintain the quality of our network.
              </p>
            </div>
          </div>

          <div className="mentor-verification-note">
            <i className="bi bi-shield-lock" />
            <div>
              <b>Verification is handled confidentially</b>
              <p>
                Our team may review professional documents, contact references
                and arrange an interview or in-person verification. Your
                application is not a public profile.
              </p>
            </div>
          </div>

          <Field label="Work email verification">
            {workEmailVerified ? (
              <p>
                <i className="bi bi-patch-check-fill" /> Work email verified
                {status?.work_email_masked
                  ? ` (${status.work_email_masked})`
                  : ""}
              </p>
            ) : (
              <>
                <input
                  type="email"
                  value={workEmail}
                  onChange={(e) => setWorkEmail(e.target.value)}
                  placeholder="name@company.com"
                  disabled={sendingOtp || verifyingOtp}
                />

                {!otpSent ? (
                  <button
                    type="button"
                    className="mentor-btn mentor-btn-outline"
                    disabled={sendingOtp || !workEmail.trim()}
                    onClick={sendOtp}
                  >
                    {sendingOtp ? "Sending code…" : "Send verification code"}
                  </button>
                ) : (
                  <>
                    <input
                      inputMode="numeric"
                      autoComplete="one-time-code"
                      maxLength={6}
                      value={otp}
                      onChange={(e) =>
                        setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))
                      }
                      placeholder="Enter 6-digit code"
                    />
                    <div className="mentor-submit-actions">
                      <button
                        type="button"
                        className="mentor-btn mentor-btn-primary"
                        disabled={verifyingOtp || otp.length !== 6}
                        onClick={verifyOtp}
                      >
                        {verifyingOtp ? "Verifying…" : "Verify email"}
                      </button>
                      <button
                        type="button"
                        className="mentor-btn mentor-btn-outline"
                        disabled={sendingOtp}
                        onClick={sendOtp}
                      >
                        Resend code
                      </button>
                    </div>
                  </>
                )}
              </>
            )}
          </Field>

          <label className="mentor-consent">
            <input
              type="checkbox"
              checked={form.has_no_work_email}
              disabled={workEmailVerified}
              onChange={(e) => update("has_no_work_email", e.target.checked)}
            />
            <span>
              I do not have access to a professional work email and will provide
              an alternative proof document.
            </span>
          </label>

          {form.has_no_work_email && (
            <Field
              label="Professional proof document"
              hint="PDF, JPG or PNG. Maximum 10 MB. Do not upload unnecessary personal information."
            >
              {proofName && <p>Uploaded document: {proofName}</p>}
              <input
                type="file"
                accept="application/pdf,image/jpeg,image/png"
                onChange={(e) => {
                  handleUpload("proof", e.target.files?.[0]);
                  e.target.value = "";
                }}
                disabled={Boolean(uploading)}
              />
              {uploading === "proof" && <small>Uploading document…</small>}
              {proofName && (
                <button
                  type="button"
                  className="mentor-btn mentor-btn-outline"
                  disabled={Boolean(uploading)}
                  onClick={() => removeUpload("proof")}
                >
                  Remove document
                </button>
              )}
            </Field>
          )}

          <Field label="Anything our review team should know?">
            <textarea
              rows={3}
              maxLength={1000}
              value={form.note_for_team}
              onChange={(e) => update("note_for_team", e.target.value)}
              placeholder="Optional context for the verification team"
            />
          </Field>

          <label className="mentor-consent">
            <input
              type="checkbox"
              required
              checked={form.accept_code_of_conduct}
              onChange={(e) =>
                update("accept_code_of_conduct", e.target.checked)
              }
            />
            <span>
              I confirm that the information provided is accurate, I will not
              share confidential employer or client information, and I agree to
              the TConnects mentor code of conduct and verification process.
            </span>
          </label>
        </section>
        )}

        {currentStep > 0 && (
          <div className="mentor-submit-bar mentor-wizard-footer">
            <div className="mentor-wizard-footer-copy">
              <b>{currentStep === steps.length - 1 ? "Almost there" : `Step ${currentStep} of ${steps.length - 1}`}</b>
              <span>{currentStep === steps.length - 1 ? "Submit when your details and verification are ready." : "Your answers stay on this page as you move between steps."}</span>
            </div>
            <div className="mentor-submit-actions">
              <button type="button" className="mentor-btn mentor-btn-outline" onClick={() => goToStep(currentStep - 1)} disabled={saving || submitting || Boolean(uploading)}>Back</button>
              <button type="button" className="mentor-btn mentor-btn-outline" disabled={saving || submitting || Boolean(uploading)} onClick={() => save({ sectionsOnly: ({ 1: [1], 2: [2], 3: [3, 4], 4: [5], 5: [6] })[currentStep] })}>
                {saving ? "Saving…" : "Save draft"}
              </button>
              {currentStep < steps.length - 1 ? (
                <button type="button" className="mentor-btn mentor-btn-primary" onClick={() => goToStep(currentStep + 1)} disabled={saving || submitting || Boolean(uploading)}>Continue <i className="bi bi-arrow-right" /></button>
              ) : (
                <button type="submit" className="mentor-btn mentor-btn-primary" disabled={saving || submitting || Boolean(uploading)}>
                  {submitting ? "Submitting…" : "Submit for verification →"}
                </button>
              )}
            </div>
          </div>
        )}
      </form>
    </main>
  );
}