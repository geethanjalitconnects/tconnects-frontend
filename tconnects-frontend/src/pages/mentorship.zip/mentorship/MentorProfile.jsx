import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { mentorshipApi } from "../../services/mentorshipApi";
import "./mentorship.css";

export default function MentorProfile() {
  const { slug } = useParams();
  const [mentor, setMentor] = useState(null);
  const [error, setError] = useState("");
  useEffect(() => {
    mentorshipApi.getMentor(slug).then(setMentor).catch(() => setError("This mentor profile could not be found."));
  }, [slug]);

  if (error) return <main className="mentorship-page"><p className="mentor-error">{error}</p><Link to="/mentorship/mentors">Back to mentors</Link></main>;
  if (!mentor) return <main className="mentorship-page"><p className="mentor-state">Loading mentor profile…</p></main>;

  return (
    <main className="mentorship-page mentor-detail-page">
      <Link className="mentor-back-link" to="/mentorship/mentors">← All mentors</Link>
      <section className="mentor-detail-card">
        <div className="mentor-detail-main">
          {mentor.photo_url ? <img className="mentor-detail-avatar" src={mentor.photo_url} alt="" /> : <div className="mentor-detail-avatar mentor-avatar-fallback">{(mentor.full_name || "M").charAt(0)}</div>}
          <span className="mentor-verified"><i className="bi bi-patch-check-fill" /> TConnects verified</span>
          <h1>{mentor.full_name}</h1>
          <p className="mentor-card-role">{mentor.job_title}</p>
          <p className="mentor-card-location">{[mentor.city, mentor.country].filter(Boolean).join(", ")}</p>
          <div className="mentor-chip-row">{(mentor.risk_areas || []).map((item) => <span className="mentor-chip" key={item}>{item}</span>)}</div>
          <h2>About</h2><p className="mentor-long-copy">{mentor.help_summary || "This mentor has not added a public summary yet."}</p>
          {mentor.past_roles?.length > 0 && <><h2>Professional experience</h2><div className="mentor-experience-list">{mentor.past_roles.map((role, i) => <div key={`${role.company_name}-${i}`}><b>{role.job_title}</b><span>{role.company_name} · {role.years} years</span></div>)}</div></>}
        </div>
        <aside className="mentor-booking-panel">
          <span className="mentor-eyebrow">MENTORING RATE</span>
          <div className="mentor-rate">₹{Number(mentor.hourly_rate || 0).toLocaleString("en-IN")}<small> / hour</small></div>
          <p>Session durations and availability are confirmed during booking.</p>
          <button className="mentor-btn mentor-btn-primary" type="button" onClick={() => window.alert("Booking and payment will be enabled after the booking API is implemented.")}>Booking coming soon</button>
          <small className="mentor-booking-note">Secure booking and payment integration is a separate implementation phase.</small>
        </aside>
      </section>
    </main>
  );
}
