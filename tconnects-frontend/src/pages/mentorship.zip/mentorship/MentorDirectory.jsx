import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { mentorshipApi } from "../../services/mentorshipApi";
import "./mentorship.css";

export default function MentorDirectory() {
  const [mentors, setMentors] = useState([]);
  const [options, setOptions] = useState({});
  const [search, setSearch] = useState("");
  const [area, setArea] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([mentorshipApi.getMentors(), mentorshipApi.getOptions()])
      .then(([people, opts]) => { setMentors(people); setOptions(opts || {}); })
      .catch(() => setError("We couldn't load mentors right now. Please refresh and try again."))
      .finally(() => setLoading(false));
  }, []);

  const visible = mentors.filter((mentor) => {
    const text = `${mentor.full_name || ""} ${(mentor.risk_areas || []).join(" ")} ${(mentor.job_title || "")}`.toLowerCase();
    return text.includes(search.toLowerCase()) && (!area || (mentor.risk_areas || []).includes(area));
  });

  return (
    <main className="mentorship-page mentor-directory-page">
      <section className="mentor-directory-heading">
        <span className="mentor-eyebrow">TCONNECTS MENTOR NETWORK</span>
        <h1>Find guidance from people who've done the work.</h1>
        <p>Explore approved professionals across risk management and related specializations.</p>
        <div className="mentor-filters">
          <label className="mentor-search"><i className="bi bi-search" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search expertise or mentor" /></label>
          <select aria-label="Filter by expertise" value={area} onChange={(e) => setArea(e.target.value)}>
            <option value="">All specializations</option>
            {(options.risk_areas || []).map((item) => <option key={item.value || item} value={item.value || item}>{item.label || item}</option>)}
          </select>
        </div>
      </section>

      {loading && <p className="mentor-state">Loading verified mentors…</p>}
      {error && <p className="mentor-error" role="alert">{error}</p>}
      {!loading && !error && visible.length === 0 && <div className="mentor-empty"><h2>No mentors found yet</h2><p>Try another search or check back as our verified network grows.</p></div>}
      <section className="mentor-card-grid">
        {visible.map((mentor) => (
          <article className="mentor-profile-card" key={mentor.slug}>
            <div className="mentor-card-top">
              {mentor.photo_url ? <img className="mentor-avatar" src={mentor.photo_url} alt="" /> : <div className="mentor-avatar mentor-avatar-fallback">{(mentor.full_name || "M").charAt(0)}</div>}
              <span className="mentor-verified"><i className="bi bi-patch-check-fill" /> Verified</span>
            </div>
            <h2>{mentor.full_name}</h2>
            <p className="mentor-card-role">{mentor.job_title || "Risk Management Professional"}</p>
            <p className="mentor-card-location">{[mentor.city, mentor.country].filter(Boolean).join(", ")}</p>
            <div className="mentor-card-meta"><span>{mentor.years_experience || "—"} years' experience</span><span>₹{Number(mentor.hourly_rate || 0).toLocaleString("en-IN")}/hr</span></div>
            <div className="mentor-chip-row">{(mentor.risk_areas || []).slice(0, 3).map((item) => <span className="mentor-chip" key={item}>{item}</span>)}</div>
            <Link className="mentor-card-link" to={`/mentorship/mentors/${mentor.slug}`}>View profile <span aria-hidden="true">→</span></Link>
          </article>
        ))}
      </section>
    </main>
  );
}
